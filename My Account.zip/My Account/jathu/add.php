<?php




// php select option value from database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "products";

// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);


if(isset ($_POST['sub'])) {
    $proID = $_POST['proID'];
       $Weight = $_POST['Weight'];
	      $quantity= $_POST['quantity'];
 
		     $Message= $_POST['Message'];
			   
	     
            


 
$sql = "INSERT INTO `addtocart`(`ID`, `proID`, `Message`, `weight`, `quantity`)
VALUES ('','$proID','$Message','$Weight',' $quantity')";

if (mysqli_query($connect, $sql)) {
   $success=  "Card successfully added";
   echo "<script type='text/javascript'>alert('$success');</script>";
  header('Location: addCart.php'); 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($connect);
    mysqli_close($connect);
}

mysqli_close($connect);

}

?> 