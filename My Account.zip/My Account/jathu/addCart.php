

<?php


$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = ''; // Password
$db_name = 'products'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}



$sql = 'SELECT `productID`, `Availability`, `Price`,`Proname`,`IMGpath` FROM `products`';
		
$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
</head>
<style>
.btn-product{
	width: 100%;
}
</style>
<body>
<div class="product-filter">
        <div class="row">
          <div class="col-md-5">
            <div class="btn-group">
              <button type="button" id="list-view" class="btn btn-default" data-toggle="tooltip" title="" data-original-title="List"><i class="fa fa-th-list"></i></button>
              <button type="button" id="grid-view" class="btn btn-default selected" data-toggle="tooltip" title="" data-original-title="Grid"><i class="fa fa-th"></i></button>
            </div>
            <a href="http://www.yarlolaigifts.com/index.php?route=product/compare" id="compare-total">Product Compare (0)</a> </div>
             <div class="col-md-4 col-xs-6">
          <div class="form-group input-group input-group-sm">
            <label class="input-group-addon" for="input-sort">Sort By:</label>
            <select id="input-sort" class="form-control" onchange="location = this.value;">
                                          <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=p.sort_order&amp;order=ASC" selected="selected">Default</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=pd.name&amp;order=ASC">Name (A - Z)</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=pd.name&amp;order=DESC">Name (Z - A)</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=p.price&amp;order=ASC">Price (Low &gt; High)</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=p.price&amp;order=DESC">Price (High &gt; Low)</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=rating&amp;order=DESC">Rating (Highest)</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=rating&amp;order=ASC">Rating (Lowest)</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=p.model&amp;order=ASC">Model (A - Z)</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;sort=p.model&amp;order=DESC">Model (Z - A)</option>
                                        </select>
          </div>
        </div>
        <div class="col-md-3 col-xs-6">
          <div class="form-group input-group input-group-sm">
            <label class="input-group-addon" for="input-limit">Show:</label>
            <select id="input-limit" class="form-control" onchange="location = this.value;">
                                          <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;limit=24" selected="selected">24</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;limit=25">25</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;limit=50">50</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;limit=75">75</option>
                                                        <option value="http://www.yarlolaigifts.com/index.php?route=product/category&amp;path=60&amp;limit=100">100</option>
                                        </select>
          </div>
        </div>
        </div>
      </div>


<div class="container">
    <div class="row">
    	<div class="col-md-12">


	<?php
while ($row = mysqli_fetch_array($query))
		{
?>
	<div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info"><?php echo $row['Proname']; ?></span></h4>
					<img src="<?php echo $row['IMGpath']; ?>" class="img-responsive" style="height:100px;">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3><?php echo $row['Proname']; ?></h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h3>
								<label><?php echo $row['Price']; ?></label></h3>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-6">
								
							</div>
							<div class="col-md-6">

								<a href="Love Rose Cake.php?id=<?php echo $row['productID'];?>" class="btn btn-success btn-product"><span class="glyphicon glyphicon-shopping-cart"></span>ADD TO CART</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
<?php

}
            ?>
        </div> 

	</div>
</div>


</body>
</html>